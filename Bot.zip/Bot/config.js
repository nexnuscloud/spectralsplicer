module.exports = {
    client: {
        token: 'MTIzNDQ4MTc5NTMyODkwMTIwMw.GARNo0.JPdLEoAarHStR1NyIrXyZ3PfwBq9TTTl7tBLFo', // ← Your bot token (.env IS RECOMMENDED)
        id: '1234481795328901203' // ← Your bot ID
    },
    modmail: {
        guildId: '1238409889726861362', // ← Your server ID
        categoryId: '1238409891635531779', // ← The modmail category ID
        staffRoles: ['1238409889768935487'], // ← The modmail staff roles IDs
        mentionStaffRolesOnNewMail: true // ← Mention staff roles when there is a new mail?
    },
    logs: {
        webhookURL: 'https://discord.com/api/webhooks/1241638165517832223/rQEVSJ9GiyO0M6tRydzhk2m1cG1XeLG1g1IwgBRxJtOrQYdYMYLjpPqPFW5mI8o0HMwR' // ← The logging webhook URL (OPTIONAL) (.env IS RECOMMENDED)
    }
};